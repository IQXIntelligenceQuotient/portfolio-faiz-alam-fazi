import React from "react";
import ServiceLayout from "../../components/ServiceLayout.jsx";
import { servicesData } from "../../Data/servicesData.js";
import SEOHead from "../../components/seo/SEOHead.jsx";
import PakistanCoverage from "../../components/seo/PakistanCoverage.jsx";

const schemaConfig = {
  slug: "/Representation",
  name: "Legal Representation Services in Pakistan",
  title: "Professional Legal Representation for Disputes, Negotiations, and Litigation in Pakistan",
  description:
    "Strategic legal representation for negotiations, mediation, and litigation across Pakistan. Professional advocacy in Lahore, Karachi, Islamabad, Rawalpindi for disputes, business conflicts, and legal proceedings.",
  serviceType: "Legal Representation",
  image: "https://faizalamfaizi.com/6. Online Courtroom Representation in Lahore Pakistan.webp",
  areaServed: [
    "Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad",
    "Multan", "Peshawar", "Quetta", "Gujranwala", "Sialkot", "Pakistan",
  ],
  keywords: [
    "legal representation Pakistan", "court representation Lahore", "litigation services Karachi",
    "legal advocacy Islamabad", "dispute resolution Pakistan", "lawyer Rawalpindi",
    "legal representation near me",
  ],
  audience: "Individuals, businesses, and organizations involved in legal disputes in Pakistan",
};

function Representation() {
  return (
    <>
      <SEOHead
        title="Legal Representation Services in Pakistan | Court & Dispute Advocacy Lahore, Karachi"
        description="Strategic legal representation for negotiations, mediation, and litigation across Pakistan. Professional advocacy services in Lahore, Karachi, Islamabad, Rawalpindi for disputes, business conflicts, and legal proceedings."
        keywords="legal representation Pakistan, court representation Lahore, litigation services Karachi, legal advocacy Islamabad, dispute resolution Pakistan, lawyer Rawalpindi, legal representation near me"
        canonical="/Representation"
        ogImage="/6.%20Online%20Courtroom%20Representation%20in%20Lahore%20Pakistan.webp"
      />
      <ServiceLayout
        content={servicesData.representation}
        faqKey="representation"
        schemaConfig={schemaConfig}
      />
      <PakistanCoverage serviceName="Legal Representation Services" />
    </>
  );
}

export default Representation;
