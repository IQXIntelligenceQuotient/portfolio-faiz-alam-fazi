import React from "react";
import ServiceLayout from "../../components/ServiceLayout.jsx";
import { servicesData } from "../../Data/servicesData.js";
import SEOHead from "../../components/seo/SEOHead.jsx";
import PakistanCoverage from "../../components/seo/PakistanCoverage.jsx";

const schemaConfig = {
  slug: "/DocumentDrafting",
  name: "Legal Document Drafting and Review Services in Pakistan",
  title: "Professional Legal Document Drafting and Review Services in Pakistan",
  description:
    "Professional legal document drafting and review services across Pakistan. Expert preparation of contracts, agreements, legal notices, and corporate documents in Lahore, Karachi, Islamabad, Rawalpindi.",
  serviceType: "Legal Document Drafting",
  image: "https://faizalamfaizi.com/3. Online Document Drafting and Review in Lahore Pakistan.webp",
  areaServed: [
    "Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad",
    "Multan", "Peshawar", "Quetta", "Gujranwala", "Sialkot", "Pakistan",
  ],
  keywords: [
    "document drafting Pakistan", "legal document review Lahore", "contract drafting Karachi",
    "agreement preparation Islamabad", "legal notice Pakistan", "document services Rawalpindi",
    "contract review near me Pakistan",
  ],
  audience: "Individuals, startups, and businesses needing legal documents in Pakistan",
};

function DocumentDrafting() {
  return (
    <>
      <SEOHead
        title="Legal Document Drafting & Review in Pakistan | Contracts, Agreements Lahore, Karachi"
        description="Professional legal document drafting and review services across Pakistan. Expert preparation of contracts, agreements, legal notices, and corporate documents in Lahore, Karachi, Islamabad, Rawalpindi, and all major cities."
        keywords="document drafting Pakistan, legal document review Lahore, contract drafting Karachi, agreement preparation Islamabad, legal notice Pakistan, document services Rawalpindi, contract review near me Pakistan"
        canonical="/DocumentDrafting"
        ogImage="/3.%20Online%20Document%20Drafting%20and%20Review%20in%20Lahore%20Pakistan.webp"
      />
      <ServiceLayout
        content={servicesData.documentDrafting}
        faqKey="documentDrafting"
        schemaConfig={schemaConfig}
      />
      <PakistanCoverage serviceName="Document Drafting & Review Services" />
    </>
  );
}

export default DocumentDrafting;
