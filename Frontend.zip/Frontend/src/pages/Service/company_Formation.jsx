import React from "react";
import ServiceLayout from "../../components/ServiceLayout.jsx";
import { servicesData } from "../../Data/servicesData.js";
import SEOHead from "../../components/seo/SEOHead.jsx";
import PakistanCoverage from "../../components/seo/PakistanCoverage.jsx";

const schemaConfig = {
  slug: "/company_formation",
  name: "Company Formation Services in Pakistan",
  title: "Professional Company Formation and Business Registration Services in Pakistan",
  description:
    "Professional company formation and business registration services across Pakistan. Expert guidance for company setup, incorporation, and compliance in Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad.",
  serviceType: "Company Formation",
  image: "https://faizalamfaizi.com/9. Online Company Formation Services in Lahore Pakistan.webp",
  areaServed: [
    "Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad",
    "Multan", "Peshawar", "Quetta", "Gujranwala", "Sialkot", "Pakistan",
  ],
  keywords: [
    "company formation Pakistan", "business registration Lahore", "company registration Karachi",
    "incorporation services Islamabad", "startup registration Pakistan", "company setup Rawalpindi",
    "register company near me Pakistan",
  ],
  audience: "Entrepreneurs, startups, and businesses registering companies in Pakistan",
};

function Company_Formation() {
  return (
    <>
      <SEOHead
        title="Company Formation in Pakistan | Business Registration Services Lahore, Karachi, Islamabad"
        description="Professional company formation and business registration services across Pakistan. Expert guidance for company setup, incorporation, and compliance in Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad, Multan."
        keywords="company formation Pakistan, business registration Lahore, company registration Karachi, incorporation services Islamabad, startup registration Pakistan, company setup Rawalpindi, register company near me Pakistan"
        canonical="/company_formation"
        ogImage="/9.%20Online%20Company%20Formation%20Services%20in%20Lahore%20Pakistan.webp"
      />
      <ServiceLayout
        content={servicesData.companyFormation}
        faqKey="companyFormation"
        schemaConfig={schemaConfig}
      />
      <PakistanCoverage serviceName="Company Formation Services" />
    </>
  );
}

export default Company_Formation;
