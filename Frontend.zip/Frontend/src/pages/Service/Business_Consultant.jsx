import React from "react";
import ServiceLayout from "../../components/ServiceLayout.jsx";
import { servicesData } from "../../Data/servicesData.js";
import SEOHead from "../../components/seo/SEOHead.jsx";
import PakistanCoverage from "../../components/seo/PakistanCoverage.jsx";

const schemaConfig = {
  slug: "/Business_Consultant",
  name: "Business Consultant Services in Pakistan",
  title: "Professional Business Consulting for Strategy, Compliance, and Growth in Pakistan",
  description:
    "Professional business consultancy services for strategy, compliance, and growth across Pakistan. Expert business advisory for startups and companies in Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad.",
  serviceType: "Business Consultancy",
  image: "https://faizalamfaizi.com/7. Online Business Consultant in Lahore Pakistan.webp",
  areaServed: [
    "Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad",
    "Multan", "Peshawar", "Quetta", "Gujranwala", "Sialkot", "Pakistan",
  ],
  keywords: [
    "business consultant Pakistan", "business advisory Lahore", "business strategy Karachi",
    "startup consultant Islamabad", "business planning Pakistan", "corporate consultant Rawalpindi",
    "best business consultant near me Pakistan",
  ],
  audience: "Entrepreneurs, startups, and established businesses in Pakistan",
};

function Business_Consultant() {
  return (
    <>
      <SEOHead
        title="Business Consultant in Pakistan | Strategic Business Advisory Lahore, Karachi, Islamabad"
        description="Professional business consultancy services for strategy, compliance, and growth across Pakistan. Expert business advisory for startups and companies in Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad, Multan."
        keywords="business consultant Pakistan, business advisory Lahore, business strategy Karachi, startup consultant Islamabad, business planning Pakistan, corporate consultant Rawalpindi, best business consultant near me Pakistan"
        canonical="/Business_Consultant"
        ogImage="/7.%20Online%20Business%20Consultant%20in%20Lahore%20Pakistan.webp"
      />
      <ServiceLayout
        content={servicesData.businessConsultant}
        faqKey="businessConsultant"
        schemaConfig={schemaConfig}
      />
      <PakistanCoverage serviceName="Business Consultancy Services" />
    </>
  );
}

export default Business_Consultant;
