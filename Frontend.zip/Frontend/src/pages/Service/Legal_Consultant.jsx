import React from "react";
import ServiceLayout from "../../components/ServiceLayout.jsx";
import { servicesData } from "../../Data/servicesData.js";
import SEOHead from "../../components/seo/SEOHead.jsx";
import PakistanCoverage from "../../components/seo/PakistanCoverage.jsx";

const schemaConfig = {
  slug: "/Legal_Consultant",
  name: "Legal Consultant Services in Pakistan",
  title: "Trusted Legal Consultancy Services for Businesses and Individuals in Pakistan",
  description:
    "Professional legal consultancy services for individuals, startups, and businesses across Pakistan. Expert legal advice, contract review, compliance guidance, and dispute prevention in Lahore, Karachi, Islamabad, Rawalpindi.",
  serviceType: "Legal Consultancy",
  image: "https://faizalamfaizi.com/1-Best-Legal_Consultant-near-me.webp",
  areaServed: [
    "Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad",
    "Multan", "Peshawar", "Quetta", "Gujranwala", "Sialkot", "Pakistan",
  ],
  keywords: [
    "legal consultant Pakistan", "legal advice Lahore", "legal consultancy Karachi",
    "legal services Islamabad", "contract review Pakistan", "compliance consultant",
    "legal expert Rawalpindi", "advocate Pakistan", "best legal consultant near me",
  ],
  audience: "Individuals, startups, businesses, and organizations in Pakistan",
};

function Legal_Consultant() {
  return (
    <>
      <SEOHead
        title="Legal Consultant in Pakistan | Expert Legal Advice in Lahore, Karachi, Islamabad"
        description="Professional legal consultancy services for individuals, startups, and businesses across Pakistan. Get expert legal advice, contract review, compliance guidance, and dispute prevention in Lahore, Karachi, Islamabad, Rawalpindi, and all major cities."
        keywords="legal consultant Pakistan, legal advice Lahore, legal consultancy Karachi, legal services Islamabad, contract review Pakistan, compliance consultant, legal expert Rawalpindi, advocate Pakistan, best legal consultant near me"
        canonical="/Legal_Consultant"
        ogImage="/1-Best-Legal_Consultant-near-me.webp"
      />
      <ServiceLayout
        content={servicesData.legalConsultant}
        faqKey="legalConsultant"
        schemaConfig={schemaConfig}
      />
      <PakistanCoverage serviceName="Legal Consultancy Services" />
    </>
  );
}

export default Legal_Consultant;
