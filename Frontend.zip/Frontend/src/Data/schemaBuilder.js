import { siteMeta } from "./siteMeta";

export function buildServiceSchemas(content, schemaConfig, faqs = []) {
  const pageUrl = `${siteMeta.siteUrl}${schemaConfig.slug}`;
  const image = schemaConfig.image || content?.left_img || siteMeta.defaultImage;

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: schemaConfig.name || content?.h1,
    headline: content?.Hero_H1 || schemaConfig.title || content?.h1,
    description: schemaConfig.description || content?.Hero_p,
    serviceType: schemaConfig.serviceType || content?.h1,
    url: pageUrl,
    image,
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": pageUrl
    },
    provider: {
      "@type": siteMeta.providerType,
      name: siteMeta.providerName,
      url: siteMeta.siteUrl,
      image: siteMeta.logo,
      telephone: siteMeta.telephone,
      address: {
        "@type": "PostalAddress",
        ...siteMeta.address
      },
      sameAs: siteMeta.sameAs
    },
    areaServed: (schemaConfig.areaServed || siteMeta.areaServed).map((place) => ({
      "@type": "Place",
      name: place
    })),
    audience: {
      "@type": "Audience",
      audienceType: schemaConfig.audience || "Individuals, startups, businesses, organizations"
    },
    offers: {
      "@type": "Offer",
      url: content?.cta_link || siteMeta.whatsappUrl,
      availability: "https://schema.org/InStock"
    },
    potentialAction: {
      "@type": "CommunicateAction",
      target: {
        "@type": "EntryPoint",
        urlTemplate: content?.cta_link || siteMeta.whatsappUrl
      }
    }
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: siteMeta.siteUrl
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Services",
        item: `${siteMeta.siteUrl}/services`
      },
      {
        "@type": "ListItem",
        position: 3,
        name: schemaConfig.title || content?.h1,
        item: pageUrl
      }
    ]
  };

  const webPageSchema = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    name: content?.Hero_H1 || schemaConfig.title || content?.h1,
    url: pageUrl,
    description: schemaConfig.description || content?.Hero_p,
    primaryImageOfPage: {
      "@type": "ImageObject",
      url: image
    },
    keywords: schemaConfig.keywords?.join(", ")
  };

  const faqSchema =
    faqs.length > 0
      ? {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: faqs.map((item) => ({
            "@type": "Question",
            name: item.question,
            acceptedAnswer: {
              "@type": "Answer",
              text: item.answer
            }
          }))
        }
      : null;

  return [serviceSchema, breadcrumbSchema, webPageSchema, faqSchema].filter(Boolean);
}