export const siteMeta = {
  siteName: "Faiz Alam Faizi",
  siteUrl: "https://faizalamfaizi.com",
  whatsappUrl: "https://wa.me/923214277856",
  logo: "https://faizalamfaizi.com/favicon.png",
  defaultImage: "https://faizalamfaizi.com/og-default.jpg",
  providerName: "Advocate Faiz Alam Faizi",
  providerType: "Person",
  email: "info@faizalamfaizi.com",
  telephone: "+92-321-4277856",
  address: {
    streetAddress: "Garden Town",
    addressLocality: "Lahore",
    addressRegion: "Punjab",
    addressCountry: "PK",
    postalCode: "54000"
  },
  areaServed: [
    "Pakistan", "Lahore", "Islamabad", "Karachi", "Rawalpindi",
    "Faisalabad", "Multan", "Gujranwala", "Sialkot", "Peshawar",
    "Quetta", "Hyderabad", "Abbottabad", "Gwadar", "Bahawalpur"
  ],
  sameAs: [
    "https://www.facebook.com/FaizAlamFaizi/",
    "https://www.instagram.com/legalbridgellp/",
    "https://www.linkedin.com/in/faiz-alam-faizi-950a1b270/",
    "https://www.tiktok.com/@faizalamfaizi"
  ]
};