/**
 * Schema Generator for Pakistan SEO + AEO Optimization
 * Generates JSON-LD structured data for all page types
 */

const siteUrl = 'https://faizalamfaizi.com';
const businessName = 'Faiz Alam Faizi';
const logoUrl = `${siteUrl}/Business_Consultant_in_Lahore_Pakistan.svg`;

// Pakistan cities coverage
export const pakistanCities = {
  punjab: [
    'Lahore, Punjab',
    'Faisalabad, Punjab',
    'Rawalpindi, Punjab',
    'Multan, Punjab',
    'Gujranwala, Punjab',
    'Sialkot, Punjab',
    'Bahawalpur, Punjab',
    'Sargodha, Punjab',
    'Sheikhupura, Punjab',
    'Rahim Yar Khan, Punjab',
    'Jhelum, Punjab',
    'Gujrat, Punjab',
    'Okara, Punjab',
  ],
  sindh: [
    'Karachi, Sindh',
    'Hyderabad, Sindh',
    'Sukkur, Sindh',
    'Larkana, Sindh',
    'Nawabshah, Sindh',
    'Mirpur Khas, Sindh',
    'Jacobabad, Sindh',
  ],
  kpk: [
    'Peshawar, Khyber Pakhtunkhwa',
    'Abbottabad, Khyber Pakhtunkhwa',
    'Mardan, Khyber Pakhtunkhwa',
    'Swat, Khyber Pakhtunkhwa',
    'Kohat, Khyber Pakhtunkhwa',
    'Bannu, Khyber Pakhtunkhwa',
    'Dera Ismail Khan, Khyber Pakhtunkhwa',
  ],
  balochistan: [
    'Quetta, Balochistan',
    'Gwadar, Balochistan',
    'Turbat, Balochistan',
    'Khuzdar, Balochistan',
  ],
  islamabad: ['Islamabad Capital Territory'],
};

// Flatten all cities
export const allPakistanCities = [
  ...pakistanCities.punjab,
  ...pakistanCities.sindh,
  ...pakistanCities.kpk,
  ...pakistanCities.balochistan,
  ...pakistanCities.islamabad,
];

/**
 * Generate Organization Schema
 */
export function generateOrganizationSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'LegalService',
    '@id': `${siteUrl}/#organization`,
    name: businessName,
    url: siteUrl,
    logo: logoUrl,
    image: logoUrl,
    description:
      'Professional legal consultancy, business advisory, tax services, and documentation support across Pakistan',
    telephone: '+92-321-4277856',
    email: 'info@faizalamfaizi.com',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Garden Town',
      addressLocality: 'Lahore',
      addressRegion: 'Punjab',
      postalCode: '54000',
      addressCountry: 'PK',
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: '31.5204',
      longitude: '74.3587',
    },
    areaServed: allPakistanCities.map((city) => ({
      '@type': 'City',
      name: city,
    })),
    priceRange: '$$',
    openingHours: 'Mo-Sa 09:00-18:00',
    sameAs: [
      'https://www.facebook.com/FaizAlamFaizi/',
      'https://www.instagram.com/legalbridgellp/',
      'https://www.linkedin.com/in/faiz-alam-faizi-950a1b270/',
    ],
  };
}

/**
 * Generate WebSite Schema
 */
export function generateWebSiteSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    '@id': `${siteUrl}/#website`,
    url: siteUrl,
    name: businessName,
    description:
      'Legal consultant, business advisor, and professional services provider in Pakistan',
    publisher: {
      '@id': `${siteUrl}/#organization`,
    },
    inLanguage: 'en-PK',
    potentialAction: {
      '@type': 'SearchAction',
      target: `${siteUrl}/search?q={search_term_string}`,
      'query-input': 'required name=search_term_string',
    },
  };
}

/**
 * Generate WebPage Schema
 */
export function generateWebPageSchema(pageData) {
  const { title, description, url, breadcrumbs } = pageData;

  return {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    '@id': `${siteUrl}${url}#webpage`,
    url: `${siteUrl}${url}`,
    name: title,
    description: description,
    isPartOf: {
      '@id': `${siteUrl}/#website`,
    },
    about: {
      '@id': `${siteUrl}/#organization`,
    },
    inLanguage: 'en-PK',
    ...(breadcrumbs && {
      breadcrumb: {
        '@id': `${siteUrl}${url}#breadcrumb`,
      },
    }),
  };
}

/**
 * Generate Service Schema
 */
export function generateServiceSchema(serviceData) {
  const { name, description, url } = serviceData;

  return {
    '@context': 'https://schema.org',
    '@type': 'Service',
    '@id': `${siteUrl}${url}#service`,
    name: name,
    description: description,
    provider: {
      '@id': `${siteUrl}/#organization`,
    },
    areaServed: allPakistanCities.map((city) => ({
      '@type': 'City',
      name: city,
    })),
    availableChannel: {
      '@type': 'ServiceChannel',
      serviceUrl: `${siteUrl}${url}`,
      servicePhone: '+92-321-4277856',
    },
  };
}

/**
 * Generate LocalBusiness Schema
 */
export function generateLocalBusinessSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    '@id': `${siteUrl}/#localbusiness`,
    name: businessName,
    image: logoUrl,
    url: siteUrl,
    telephone: '+92-321-4277856',
    email: 'info@faizalamfaizi.com',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Garden Town',
      addressLocality: 'Lahore',
      addressRegion: 'Punjab',
      postalCode: '54000',
      addressCountry: 'PK',
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: '31.5204',
      longitude: '74.3587',
    },
    openingHoursSpecification: [
      {
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
        opens: '09:00',
        closes: '18:00',
      },
    ],
    priceRange: '$$',
    areaServed: allPakistanCities.map((city) => ({
      '@type': 'City',
      name: city,
    })),
  };
}

/**
 * Generate Breadcrumb Schema
 */
export function generateBreadcrumbSchema(breadcrumbs) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: breadcrumbs.map((crumb, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: crumb.name,
      item: `${siteUrl}${crumb.url}`,
    })),
  };
}

/**
 * Generate FAQ Schema
 */
export function generateFAQSchema(faqs) {
  if (!faqs || faqs.length === 0) return null;

  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  };
}

/**
 * Generate Person Schema (for About page)
 */
export function generatePersonSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Person',
    '@id': `${siteUrl}/#person`,
    name: 'Faiz Alam Faizi',
    url: siteUrl,
    image: `${siteUrl}/favicon.png`,
    jobTitle: 'Legal Consultant, Business Advisor, Entrepreneur',
    description:
      'Faiz Alam Faizi is a legal consultant, business advisor, and entrepreneur providing professional services across Pakistan',
    address: {
      '@type': 'PostalAddress',
      addressLocality: 'Lahore',
      addressRegion: 'Punjab',
      addressCountry: 'PK',
    },
    sameAs: [
      'https://www.facebook.com/FaizAlamFaizi/',
      'https://www.instagram.com/legalbridgellp/',
      'https://www.linkedin.com/in/faiz-alam-faizi-950a1b270/',
    ],
    worksFor: {
      '@id': `${siteUrl}/#organization`,
    },
  };
}

/**
 * Generate ContactPage Schema
 */
export function generateContactPageSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'ContactPage',
    '@id': `${siteUrl}/contact#contactpage`,
    url: `${siteUrl}/contact`,
    name: 'Contact Faiz Alam Faizi',
    description: 'Get in touch with Faiz Alam Faizi for legal and business consultancy services',
    mainEntity: {
      '@id': `${siteUrl}/#organization`,
    },
  };
}

/**
 * Generate complete schema graph for a page
 */
export function generateCompleteSchema(pageType, pageData = {}) {
  const schemas = {
    '@context': 'https://schema.org',
    '@graph': [
      generateOrganizationSchema(),
      generateWebSiteSchema(),
      generateWebPageSchema(pageData),
    ],
  };

  // Add page-specific schemas
  switch (pageType) {
    case 'home':
      schemas['@graph'].push(generateLocalBusinessSchema());
      break;

    case 'about':
      schemas['@graph'].push(generatePersonSchema());
      break;

    case 'service':
      if (pageData.service) {
        schemas['@graph'].push(generateServiceSchema(pageData.service));
      }
      break;

    case 'contact':
      schemas['@graph'].push(generateContactPageSchema());
      break;

    default:
      break;
  }

  // Add breadcrumbs if provided
  if (pageData.breadcrumbs) {
    schemas['@graph'].push(generateBreadcrumbSchema(pageData.breadcrumbs));
  }

  // Add FAQs if provided
  if (pageData.faqs) {
    const faqSchema = generateFAQSchema(pageData.faqs);
    if (faqSchema) {
      schemas['@graph'].push(faqSchema);
    }
  }

  return schemas;
}
