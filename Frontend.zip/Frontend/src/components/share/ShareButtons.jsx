import { useState } from "react";

// ─── Helpers ────────────────────────────────────────────────────────────────

export const copyToClipboard = async (text, successMsg = "Link copied!") => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // fallback for older browsers
    try {
      const el = document.createElement("textarea");
      el.value = text;
      el.style.position = "fixed";
      el.style.opacity = "0";
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      return true;
    } catch {
      return false;
    }
  }
};

export const openShareWindow = (url) => {
  window.open(url, "_blank", "noopener,noreferrer,width=700,height=600");
};

export const createShareLinks = ({ url, title }) => {
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title || "Read this blog");
  return {
    whatsapp: `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
    twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
  };
};

// ─── Icons ───────────────────────────────────────────────────────────────────

const WhatsAppIcon = () => (
  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

const FacebookIcon = () => (
  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
  </svg>
);

const LinkedInIcon = () => (
  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
  </svg>
);

const TwitterIcon = () => (
  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.737-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
  </svg>
);

const InstagramIcon = () => (
  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
  </svg>
);

const CopyIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
  </svg>
);

const CheckIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
  </svg>
);

// ─── Main Component ───────────────────────────────────────────────────────────

/**
 * ShareButtons
 * @param {string} title  - Blog post title
 * @param {string} url    - Full public URL to share
 * @param {"admin"|"public"} variant
 */
export default function ShareButtons({ title, url, variant = "public" }) {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedInsta, setCopiedInsta] = useState(false);

  const links = createShareLinks({ url, title });

  const handleCopyLink = async () => {
    const ok = await copyToClipboard(url);
    if (ok) {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleCopyInstagram = async () => {
    const text = `${title}\n${url}`;
    const ok = await copyToClipboard(text);
    if (ok) {
      setCopiedInsta(true);
      setTimeout(() => setCopiedInsta(false), 2500);
    }
  };

  // ── Admin variant (dark gold) ──────────────────────────────────────────────
  if (variant === "admin") {
    return (
      <div className="flex flex-wrap gap-2">
        {/* Copy Link */}
        <button
          type="button"
          onClick={handleCopyLink}
          title="Copy blog link"
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-300 transition hover:border-[#d4af37]/50 hover:text-[#d4af37]"
        >
          {copiedLink ? <CheckIcon /> : <CopyIcon />}
          {copiedLink ? "Copied!" : "Copy Link"}
        </button>

        {/* WhatsApp */}
        <button
          type="button"
          onClick={() => openShareWindow(links.whatsapp)}
          title="Share on WhatsApp"
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-300 transition hover:border-green-500/50 hover:text-green-400"
        >
          <WhatsAppIcon />
          WhatsApp
        </button>

        {/* Facebook */}
        <button
          type="button"
          onClick={() => openShareWindow(links.facebook)}
          title="Share on Facebook"
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-300 transition hover:border-blue-500/50 hover:text-blue-400"
        >
          <FacebookIcon />
          Facebook
        </button>

        {/* Instagram copy */}
        <button
          type="button"
          onClick={handleCopyInstagram}
          title="Copy for Instagram"
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-300 transition hover:border-pink-500/50 hover:text-pink-400"
        >
          {copiedInsta ? <CheckIcon /> : <InstagramIcon />}
          {copiedInsta ? "Copied!" : "Instagram"}
        </button>

        {/* LinkedIn */}
        <button
          type="button"
          onClick={() => openShareWindow(links.linkedin)}
          title="Share on LinkedIn"
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-300 transition hover:border-sky-500/50 hover:text-sky-400"
        >
          <LinkedInIcon />
          LinkedIn
        </button>

        {/* X / Twitter */}
        <button
          type="button"
          onClick={() => openShareWindow(links.twitter)}
          title="Share on X / Twitter"
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-300 transition hover:border-white/40 hover:text-white"
        >
          <TwitterIcon />
          X / Twitter
        </button>
      </div>
    );
  }

  // ── Public variant (clean light) ──────────────────────────────────────────
  return (
    <div className="flex flex-wrap items-center gap-2">
      {/* Copy Link */}
      <button
        type="button"
        onClick={handleCopyLink}
        title="Copy blog link"
        className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm transition hover:border-[#d4af37] hover:text-[#d4af37]"
      >
        {copiedLink ? <CheckIcon /> : <CopyIcon />}
        {copiedLink ? "Copied!" : "Copy Link"}
      </button>

      {/* WhatsApp */}
      <button
        type="button"
        onClick={() => openShareWindow(links.whatsapp)}
        title="Share on WhatsApp"
        className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm transition hover:border-green-500 hover:text-green-600"
      >
        <WhatsAppIcon />
        WhatsApp
      </button>

      {/* Facebook */}
      <button
        type="button"
        onClick={() => openShareWindow(links.facebook)}
        title="Share on Facebook"
        className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm transition hover:border-blue-600 hover:text-blue-600"
      >
        <FacebookIcon />
        Facebook
      </button>

      {/* Instagram copy */}
      <button
        type="button"
        onClick={handleCopyInstagram}
        title="Copy for Instagram"
        className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm transition hover:border-pink-500 hover:text-pink-600"
      >
        {copiedInsta ? <CheckIcon /> : <InstagramIcon />}
        {copiedInsta ? "Copied for Instagram!" : "Instagram"}
      </button>

      {/* LinkedIn */}
      <button
        type="button"
        onClick={() => openShareWindow(links.linkedin)}
        title="Share on LinkedIn"
        className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm transition hover:border-sky-600 hover:text-sky-600"
      >
        <LinkedInIcon />
        LinkedIn
      </button>

      {/* X / Twitter */}
      <button
        type="button"
        onClick={() => openShareWindow(links.twitter)}
        title="Share on X / Twitter"
        className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm transition hover:border-gray-900 hover:text-gray-900"
      >
        <TwitterIcon />
        X / Twitter
      </button>
    </div>
  );
}
